/* 積立シミュレーター。月複利、積立は毎月末。課税口座は売却した場合の手取り(約20.315%課税)。 */
(function () {
  var TAX = 0.20315;
  var $ = function (s) { return document.querySelector(s); };

  function yen(n) {
    n = Math.max(0, n);
    if (n >= 1e8) return Number((n / 1e8).toFixed(2)) + '億円';
    if (n >= 1e4) {
      var v = n / 1e4;
      return (v >= 1000 ? Math.round(v).toLocaleString('ja-JP') : Number(v.toFixed(1))) + '万円';
    }
    return Math.round(n).toLocaleString('ja-JP') + '円';
  }

  function run(monthly, init, rate, years, nisa) {
    var r = Math.pow(1 + rate, 1 / 12) - 1;
    var v = init, p = init, out = [{ y: 0, p: init, v: init }];
    for (var m = 1; m <= years * 12; m++) {
      v = v * (1 + r) + monthly;
      p += monthly;
      if (m % 12 === 0) {
        out.push({ y: m / 12, p: p, v: nisa ? v : p + Math.max(0, v - p) * (1 - TAX) });
      }
    }
    return out;
  }

  function update() {
    var monthly = Math.min(1e7, Math.max(0, parseFloat($('#sim-monthly').value) || 0));
    var init = Math.min(1e8, Math.max(0, parseFloat($('#sim-init').value) || 0));
    var rate = Math.min(0.2, Math.max(0, (parseFloat($('#sim-rate').value) || 0) / 100));
    var years = Math.min(50, Math.max(1, parseInt($('#sim-years').value, 10) || 1));
    var nisa = document.querySelector('input[name="sim-mode"]:checked').value === 'nisa';

    var main = run(monthly, init, rate, years, nisa);
    var half = run(monthly, init, rate / 2, years, nisa);
    var last = main[main.length - 1];

    $('#sim-label').textContent = years + '年後の評価額(' + (nisa ? '非課税' : '売却した場合の手取り') + ')';
    $('#sim-main').textContent = yen(last.v);
    $('#sim-detail').textContent = '元本 ' + yen(last.p) + ' / 運用益 ' + yen(last.v - last.p) +
      ' / 年利が半分の場合 ' + yen(half[half.length - 1].v);

    var marks = [1, 3, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50].filter(function (y) { return y <= years; });
    if (marks.indexOf(years) < 0) marks.push(years);
    $('#sim-body').innerHTML = marks.map(function (y) {
      var d = main[y];
      return '<tr><td>' + y + '年</td><td>' + yen(d.p) + '</td><td>' + yen(d.v) + '</td><td>' + yen(d.v - d.p) + '</td></tr>';
    }).join('');
  }

  ['#sim-monthly', '#sim-init', '#sim-rate', '#sim-years'].forEach(function (id) {
    $(id).addEventListener('input', update);
  });
  document.querySelectorAll('input[name="sim-mode"]').forEach(function (el) {
    el.addEventListener('change', update);
  });
  update();
})();
