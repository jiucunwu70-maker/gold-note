#!/usr/bin/env python3
"""為替データを取得して、静的サイト(public/)を生成する。標準ライブラリのみ使用。

使い方:
    python build.py                       # 通常のビルド(為替データをAPIから取得)
    FX_FIXTURE=tests/fixture.json python build.py   # テスト用データでビルド(ネットワーク不要)
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
import time
import urllib.request
from datetime import date, datetime, timedelta, timezone
from html import escape as esc
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "public"
CFG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
API = "https://api.frankfurter.dev/v1"
CACHE = ROOT / "data" / "fx_cache.json"
JST = timezone(timedelta(hours=9))
SITE = CFG["site_name"]
BASE = CFG["base_url"].rstrip("/")


def log(msg: str) -> None:
    print(msg, file=sys.stderr)


# --------------------------------------------------------------------------
# データ取得
# --------------------------------------------------------------------------
def http_json(url: str, tries: int = 3):
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "fx-site-builder/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.load(r)
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(2 * (i + 1))
    raise last


def fetch_pair(p: dict) -> dict:
    end = date.today()

    def one(days: int) -> dict:
        start = end - timedelta(days=days)
        d = http_json(f"{API}/{start}..{end}?base={p['base']}&symbols={p['symbol']}")
        return {k: float(v[p["symbol"]]) for k, v in d["rates"].items()}

    # daily: 直近の日次データ / long: 1年分(APIの都合で日次でない場合がある)
    return {"daily": one(100), "long": one(400)}


def load_data() -> dict:
    fixture = os.environ.get("FX_FIXTURE")
    if fixture:
        raw = json.loads(Path(fixture).read_text(encoding="utf-8"))
    else:
        cache = json.loads(CACHE.read_text(encoding="utf-8")) if CACHE.exists() else {}
        raw = {}
        for p in CFG["pairs"]:
            try:
                raw[p["slug"]] = fetch_pair(p)
            except Exception as e:  # noqa: BLE001
                log(f"[warn] {p['label']} の取得に失敗: {e}")
                if p["slug"] in cache:
                    raw[p["slug"]] = cache[p["slug"]]
                    log(f"[warn] {p['label']} は前回のデータを使います")
        CACHE.parent.mkdir(exist_ok=True)
        CACHE.write_text(json.dumps(raw), encoding="utf-8")

    data = {}
    for p in CFG["pairs"]:
        r = raw.get(p["slug"])
        if not r:
            log(f"[warn] {p['label']} のデータがないため、ページを作りません")
            continue
        daily = sorted(r["daily"].items())
        long_ = sorted(r["long"].items())
        if len(daily) < 5:
            log(f"[warn] {p['label']} のデータが少なすぎるため、ページを作りません")
            continue
        data[p["slug"]] = {"daily": daily, "long": long_ or daily}
    if not data:
        sys.exit("為替データを1件も取得できませんでした。公開済みのサイトを壊さないため、ここで終了します。")
    return data


# --------------------------------------------------------------------------
# 表示用の整形
# --------------------------------------------------------------------------
def jp_date(s: str) -> str:
    d = date.fromisoformat(s)
    return f"{d.year}年{d.month}月{d.day}日"


def short_date(s: str, with_year: bool = False) -> str:
    d = date.fromisoformat(s)
    return f"{str(d.year)[2:]}/{d.month}" if with_year else f"{d.month}/{d.day}"


def rate(v: float) -> str:
    return f"{v:,.2f}"


def signed(v: float, digits: int = 2) -> str:
    return f"{v:+,.{digits}f}"


def change(daily: list) -> tuple[float, float]:
    (_, v1), (_, v0) = daily[-1], daily[-2]
    return v1 - v0, (v1 - v0) / v0 * 100


def arrow(diff: float) -> tuple[str, str]:
    if diff > 0:
        return "▲", "up"
    if diff < 0:
        return "▼", "down"
    return "―", "flat"


def last_n_days(points: list, days: int) -> list:
    end = date.fromisoformat(points[-1][0])
    cut = (end - timedelta(days=days)).isoformat()
    return [p for p in points if p[0] >= cut]


def stats(points: list) -> dict:
    hi = max(points, key=lambda x: x[1])
    lo = min(points, key=lambda x: x[1])
    avg = sum(v for _, v in points) / len(points)
    return {"hi": hi, "lo": lo, "avg": avg}


# --------------------------------------------------------------------------
# SVG(グラフ)
# --------------------------------------------------------------------------
def chart_svg(points: list, label: str, with_year: bool = False) -> str:
    w, h = 640, 260
    ml, mr, mt, mb = 52, 14, 16, 30
    vals = [v for _, v in points]
    lo, hi = min(vals), max(vals)
    pad = (hi - lo) * 0.12 or hi * 0.01
    lo, hi = lo - pad, hi + pad
    n = len(points)

    def X(i: int) -> float:
        return ml + (w - ml - mr) * (i / (n - 1))

    def Y(v: float) -> float:
        return h - mb - (h - mt - mb) * ((v - lo) / (hi - lo))

    parts = []
    for k in range(4):
        v = lo + (hi - lo) * k / 3
        y = Y(v)
        parts.append(f'<line class="grid" x1="{ml}" x2="{w - mr}" y1="{y:.1f}" y2="{y:.1f}"/>')
        parts.append(f'<text x="{ml - 6}" y="{y + 4:.1f}" text-anchor="end">{v:.1f}</text>')
    marks = [(0, "start"), (n // 2, "middle"), (n - 1, "end")]
    for i, anchor in marks:
        parts.append(
            f'<text x="{X(i):.1f}" y="{h - 8}" text-anchor="{anchor}">{short_date(points[i][0], with_year)}</text>'
        )
    line = "".join(("L" if i else "M") + f"{X(i):.1f} {Y(v):.1f}" for i, (_, v) in enumerate(points))
    area = f"{line}L{X(n - 1):.1f} {h - mb}L{X(0):.1f} {h - mb}Z"
    parts.append(f'<path class="area" d="{area}"/>')
    parts.append(f'<path class="line" d="{line}"/>')
    lx, ly = X(n - 1), Y(points[-1][1])
    parts.append(f'<circle class="dot" cx="{lx:.1f}" cy="{ly:.1f}" r="4"/>')
    parts.append(f'<text class="end" x="{lx - 8:.1f}" y="{ly - 10:.1f}" text-anchor="end">{rate(points[-1][1])}</text>')
    aria = f"{label}の推移。{jp_date(points[0][0])}から{jp_date(points[-1][0])}まで。最新は{rate(points[-1][1])}円"
    return f'<svg class="chart" viewBox="0 0 {w} {h}" role="img" aria-label="{esc(aria)}">{"".join(parts)}</svg>'


def spark_svg(points: list) -> str:
    w, h = 110, 34
    vals = [v for _, v in points]
    lo, hi = min(vals), max(vals)
    span = (hi - lo) or 1
    n = len(points)
    pts = " ".join(
        f"{(w - 4) * i / (n - 1) + 2:.1f},{h - 4 - (h - 8) * (v - lo) / span:.1f}" for i, (_, v) in enumerate(points)
    )
    return f'<svg class="spark" viewBox="0 0 {w} {h}" aria-hidden="true"><polyline points="{pts}"/></svg>'


# --------------------------------------------------------------------------
# アフィリエイト枠(URLが空の項目は表示しない)
# --------------------------------------------------------------------------
def aff_box(group: str) -> str:
    items = [a for a in CFG.get("affiliates", {}).get(group, []) if a.get("url")]
    if not items:
        return ""
    rows = "".join(
        f'<li><div><b>{esc(a["name"])}</b><p>{esc(a.get("text", ""))}</p></div>'
        f'<a class="btn" href="{esc(a["url"])}" target="_blank" rel="sponsored nofollow noopener">公式サイトを見る</a></li>'
        for a in items
    )
    return (
        '<aside class="aff"><p class="pr">PR 広告を含みます</p>'
        f"<ul>{rows}</ul>"
        '<p class="fine">条件やキャンペーンは変わることがあります。申し込む前に、必ず公式サイトで最新の内容を確認してください。</p></aside>'
    )


def render_tokens(text: str, rel: str) -> str:
    text = text.replace("{{REL}}", rel).replace("{{SITE}}", esc(SITE))
    text = text.replace("{{OWNER}}", esc(CFG.get("owner_name") or "(運営者名を config.json に設定してください)"))
    text = text.replace("{{CONTACT}}", esc(CFG.get("contact") or "(連絡先を config.json に設定してください)"))
    text = re.sub(r"\{\{AFF:(\w+)\}\}", lambda m: aff_box(m.group(1)), text)
    return text


# --------------------------------------------------------------------------
# ページ共通
# --------------------------------------------------------------------------
def head_scripts() -> str:
    s = ""
    ads = CFG.get("adsense_client")
    if ads:
        s += (
            '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client='
            f'{esc(ads)}" crossorigin="anonymous"></script>\n'
        )
    ga = CFG.get("ga_measurement_id")
    if ga:
        s += (
            f'<script async src="https://www.googletagmanager.com/gtag/js?id={esc(ga)}"></script>\n'
            "<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}"
            f"gtag('js',new Date());gtag('config','{esc(ga)}');</script>\n"
        )
    return s


def page(*, title: str, desc: str, body: str, rel: str, path: str) -> str:
    canon = f"{BASE}/{path}" if path else f"{BASE}/"
    full_title = f"{title}|{SITE}" if path else title
    return f"""<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(full_title)}</title>
<meta name="description" content="{esc(desc)}">
<link rel="canonical" href="{esc(canon)}">
<meta property="og:title" content="{esc(full_title)}">
<meta property="og:description" content="{esc(desc)}">
<meta property="og:type" content="website">
<meta property="og:url" content="{esc(canon)}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Zen+Kaku+Gothic+New:wght@400;500;700;900&display=swap">
<link rel="stylesheet" href="{rel}static/style.css">
{head_scripts()}</head>
<body>
<header class="top"><div class="inner">
<a class="brand" href="{rel}index.html">{esc(SITE)}</a>
<nav aria-label="メインメニュー"><a href="{rel}index.html#fx">為替</a><a href="{rel}guides/index.html">ガイド</a></nav>
</div></header>
<main class="inner">
{body}
</main>
<footer class="foot"><div class="inner">
<nav aria-label="フッターメニュー"><a href="{rel}about.html">運営者情報</a><a href="{rel}privacy.html">プライバシーポリシー</a><a href="{rel}disclaimer.html">免責事項・広告表記</a></nav>
<p class="fine">掲載内容は情報提供を目的としたもので、投資の勧誘や助言ではありません。投資は元本が保証されず、損失が出ることがあります。最終的な判断はご自身で行ってください。</p>
<p class="fine">© {datetime.now(JST).year} {esc(SITE)}</p>
</div></footer>
</body>
</html>
"""


def write(path: str, html: str) -> None:
    f = OUT / path
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(html, encoding="utf-8")


# --------------------------------------------------------------------------
# 各ページ
# --------------------------------------------------------------------------
def summary_text(p: dict, daily: list) -> str:
    d1, v1 = daily[-1]
    _, v0 = daily[-2]
    diff, pct = change(daily)
    if diff > 0:
        move = f"前営業日の{rate(v0)}円から{signed(diff)}円({signed(pct)}%)上昇し、円安方向に動きました"
    elif diff < 0:
        move = f"前営業日の{rate(v0)}円から{signed(diff)}円({signed(pct)}%)下落し、円高方向に動きました"
    else:
        move = f"前営業日の{rate(v0)}円から変わりませんでした"
    return f"{jp_date(d1)}時点の{p['name']}({p['label']})は、{p['unit']}={rate(v1)}円です。{move}。"


def build_pair_page(p: dict, d: dict, all_pairs: list) -> None:
    daily, long_ = d["daily"], d["long"]
    d1, v1 = daily[-1]
    diff, pct = change(daily)
    ar, cls = arrow(diff)
    three = last_n_days(daily, 92)
    s3 = stats(three)
    s1 = stats(long_)
    rows = "".join(
        f"<tr><td>{jp_date(day)}</td><td>{rate(v)}</td></tr>" for day, v in reversed(daily[-10:])
    )
    others = "".join(
        f'<li><a href="{q["slug"]}.html">{esc(q["name"])}({q["label"]})</a></li>' for q in all_pairs if q["slug"] != p["slug"]
    )
    body = f"""
<nav class="crumb" aria-label="パンくず"><a href="../index.html">ホーム</a> / 為替 / {esc(p["name"])}</nav>
<h1>{esc(p["name"])}({p["label"]})の今日のレートと推移</h1>
<p class="stamp">{jp_date(d1)}時点の参考レート</p>
<section class="now">
<div class="big num">{rate(v1)}<small>円</small></div>
<p class="delta {cls}"><span aria-hidden="true">{ar}</span> 前営業日比 <span class="num">{signed(diff)}円({signed(pct)}%)</span></p>
</section>
<p>{esc(summary_text(p, daily))}</p>
<h2>直近3か月の推移</h2>
{chart_svg(three, p["name"] + "の直近3か月")}
<h2>過去1年の推移</h2>
{chart_svg(long_, p["name"] + "の過去1年", with_year=True)}
<h2>高値・安値・平均</h2>
<div class="scroll"><table>
<thead><tr><th></th><th>高値</th><th>安値</th><th>平均</th></tr></thead>
<tbody>
<tr><td>直近3か月</td><td>{rate(s3["hi"][1])}<small>({short_date(s3["hi"][0])})</small></td><td>{rate(s3["lo"][1])}<small>({short_date(s3["lo"][0])})</small></td><td>{rate(s3["avg"])}</td></tr>
<tr><td>過去1年</td><td>{rate(s1["hi"][1])}<small>({short_date(s1["hi"][0], True)})</small></td><td>{rate(s1["lo"][1])}<small>({short_date(s1["lo"][0], True)})</small></td><td>{rate(s1["avg"])}</td></tr>
</tbody></table></div>
<h2>直近10営業日のレート</h2>
<div class="scroll"><table><thead><tr><th>日付</th><th>1通貨あたり(円)</th></tr></thead><tbody>{rows}</tbody></table></div>
<h2>{esc(p["name"])}とは</h2>
<p>{esc(p["blurb"])}</p>
<p>円安は、外貨に対して円の価値が下がることで、{esc(p["unit"])}が買える円の数が増えます。円高は、その反対です。海外の資産に投資するときは、投資先の値動きに加えて、為替の変動も円での評価額に影響します。</p>
{aff_box("fx")}
<p class="fine">このレートは、欧州中央銀行などが公表する参考レートです。銀行や証券会社で実際に取引するレートとは異なります。取引の判断には使わず、動きの目安としてご覧ください。</p>
<h2>ほかの為替レート</h2>
<ul class="links">{others}</ul>
<p>為替の基本は、<a href="../guides/kawase-no-mikata.html">為替レートの見方</a>で解説しています。</p>
"""
    desc = f"{p['name']}({p['label']})の最新レートと、直近3か月・過去1年の推移、高値・安値を毎営業日更新。{jp_date(d1)}時点は{rate(v1)}円です。"
    write(
        f"fx/{p['slug']}.html",
        page(title=f"{p['name']}({p['label']})の今日のレートと推移", desc=desc, body=body, rel="../", path=f"fx/{p['slug']}.html"),
    )


def load_guides() -> list:
    meta_re = re.compile(r"^<!--\s*title:(.*?)\|\s*desc:(.*?)\|\s*order:\s*(\d+)\s*-->\s*", re.S)
    guides = []
    for f in sorted((ROOT / "content" / "guides").glob("*.html")):
        raw = f.read_text(encoding="utf-8")
        m = meta_re.match(raw)
        if not m:
            sys.exit(f"{f.name} の先頭に title / desc / order のコメントがありません")
        guides.append(
            {"slug": f.stem, "title": m.group(1).strip(), "desc": m.group(2).strip(), "order": int(m.group(3)), "body": raw[m.end():]}
        )
    return sorted(guides, key=lambda g: g["order"])


def build_guides(guides: list) -> None:
    for g in guides:
        others = "".join(
            f'<li><a href="{o["slug"]}.html">{esc(o["title"])}</a></li>' for o in guides if o["slug"] != g["slug"]
        )
        body = (
            f'<nav class="crumb" aria-label="パンくず"><a href="../index.html">ホーム</a> / <a href="index.html">ガイド</a></nav>\n'
            f'<article class="prose"><h1>{esc(g["title"])}</h1>\n{render_tokens(g["body"], "../")}\n</article>\n'
            f'<h2>ほかのガイド</h2><ul class="links">{others}</ul>'
        )
        write(
            f"guides/{g['slug']}.html",
            page(title=g["title"], desc=g["desc"], body=body, rel="../", path=f"guides/{g['slug']}.html"),
        )
    items = "".join(
        f'<li><a href="{g["slug"]}.html"><b>{esc(g["title"])}</b><span>{esc(g["desc"])}</span></a></li>' for g in guides
    )
    body = f'<h1>ガイド</h1><p>積立やNISA、為替の基本を、数字や制度の名前を確かめながら整理しています。</p><ul class="cards">{items}</ul>'
    write(
        "guides/index.html",
        page(title="ガイド一覧", desc="NISAの始め方、証券口座の選び方、為替レートの見方、積立シミュレーターのガイド一覧です。", body=body, rel="../", path="guides/index.html"),
    )


def build_index(data: dict, guides: list) -> None:
    rows = []
    stamp = ""
    for p in CFG["pairs"]:
        d = data.get(p["slug"])
        if not d:
            continue
        daily = d["daily"]
        diff, pct = change(daily)
        ar, cls = arrow(diff)
        stamp = max(stamp, daily[-1][0])
        rows.append(
            f'<li><a href="fx/{p["slug"]}.html">'
            f'<span class="nm"><b>{esc(p["name"])}</b><small>{p["label"]}</small></span>'
            f'{spark_svg(daily[-30:])}'
            f'<span class="rt"><span class="num v">{rate(daily[-1][1])}</span>'
            f'<span class="delta {cls}"><span aria-hidden="true">{ar}</span> <span class="num">{signed(diff)}({signed(pct)}%)</span></span></span>'
            "</a></li>"
        )
    cards = "".join(
        f'<li><a href="guides/{g["slug"]}.html"><b>{esc(g["title"])}</b><span>{esc(g["desc"])}</span></a></li>' for g in guides
    )
    updated = datetime.now(JST).strftime("%Y年%-m月%-d日 %H:%M")
    body = f"""
<section class="hero">
<h1>為替レートと積立の基本を、<wbr>毎営業日更新</h1>
<p>{esc(CFG["tagline"])}</p>
</section>
<section id="fx">
<h2>今日の為替レート</h2>
<p class="stamp">{jp_date(stamp)}時点の参考レート(サイトの更新: {updated})</p>
<ul class="rates">{"".join(rows)}</ul>
<p class="fine">1通貨あたりの円の値です。矢印は前営業日との差を示します。欧州中央銀行などが公表する参考レートで、実際の取引レートとは異なります。</p>
</section>
<section>
<h2>はじめての積立・NISAガイド</h2>
<ul class="cards">{cards}</ul>
</section>
"""
    write(
        "index.html",
        page(title=f"{SITE} 為替レートと積立・NISAの基本", desc=CFG["tagline"], body=body, rel="", path=""),
    )


def build_pages() -> None:
    pages = {
        "about": ("運営者情報", "このサイトの運営者情報です。"),
        "privacy": ("プライバシーポリシー", "個人情報の取り扱いと、アクセス解析・広告についての方針です。"),
        "disclaimer": ("免責事項・広告表記", "掲載情報の免責事項と、広告(アフィリエイト)についての表記です。"),
    }
    for slug, (title, desc) in pages.items():
        raw = (ROOT / "content" / "pages" / f"{slug}.html").read_text(encoding="utf-8")
        body = f'<article class="prose"><h1>{esc(title)}</h1>\n{render_tokens(raw, "")}</article>'
        write(f"{slug}.html", page(title=title, desc=desc, body=body, rel="", path=f"{slug}.html"))


def build_meta(urls: list) -> None:
    today = datetime.now(JST).date().isoformat()
    items = "".join(f"<url><loc>{BASE}/{u}</loc><lastmod>{today}</lastmod></url>" for u in urls)
    write("sitemap.xml", f'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{items}</urlset>\n')
    write("robots.txt", f"User-agent: *\nAllow: /\n\nSitemap: {BASE}/sitemap.xml\n")
    write(".nojekyll", "")


def main() -> None:
    if "YOUR-NAME" in CFG["base_url"]:
        log("[warn] config.json の base_url がまだ初期値です。公開後のURLに書き換えてください。")
    if not CFG.get("owner_name") or not CFG.get("contact"):
        log("[warn] config.json の owner_name / contact が空です。運営者情報ページに反映されます。公開前に設定してください。")

    data = load_data()
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir()
    shutil.copytree(ROOT / "static", OUT / "static")

    built = [p for p in CFG["pairs"] if p["slug"] in data]
    for p in built:
        build_pair_page(p, data[p["slug"]], built)
    guides = load_guides()
    build_guides(guides)
    build_index(data, guides)
    build_pages()

    urls = ["", "guides/index.html", "about.html", "privacy.html", "disclaimer.html"]
    urls += [f"fx/{p['slug']}.html" for p in built] + [f"guides/{g['slug']}.html" for g in guides]
    build_meta(urls)
    log(f"完了: 為替ページ{len(built)}件、ガイド{len(guides)}件を public/ に出力しました。")


if __name__ == "__main__":
    main()
